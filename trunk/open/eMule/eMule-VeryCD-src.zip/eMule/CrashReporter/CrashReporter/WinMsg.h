#pragma once

#define	WM_UPLOAD_PROGRESS				(WM_USER + 101)

thanks for the flag from Commander[GER] :)

simply decide 24bits or 32bits that you want,
rename ~/res32/ or ~/res24/ to ~/res/,
then compile, get what you want :)
the 32bit's one will require be renamed to countryflag32.dll to be correct load in Morph under winXP
